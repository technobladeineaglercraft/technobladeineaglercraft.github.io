# Wurst-Client
![Wurst Client logo](Wurst%20logo/wurst_1011x256.png)

## About
The Wurst Hack Client for Minecraft is packed full of the latest and most exciting mods, commands and other features. It contains over 70 mods and over 20 commands that let you rule the game.
