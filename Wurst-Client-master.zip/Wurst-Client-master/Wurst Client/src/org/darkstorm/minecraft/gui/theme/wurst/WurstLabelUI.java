/*
 * Copyright � 2014 - 2015 | Alexander01998 | All rights reserved.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
package org.darkstorm.minecraft.gui.theme.wurst;

import static org.lwjgl.opengl.GL11.GL_BLEND;
import static org.lwjgl.opengl.GL11.GL_CULL_FACE;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;

import java.awt.Color;
import java.awt.Dimension;

import org.darkstorm.minecraft.gui.component.Label;
import org.darkstorm.minecraft.gui.theme.AbstractComponentUI;
import org.darkstorm.minecraft.gui.util.RenderUtil;

public class WurstLabelUI extends AbstractComponentUI<Label>
{
	private final WurstTheme theme;
	
	WurstLabelUI(WurstTheme theme)
	{
		super(Label.class);
		this.theme = theme;
		
		foreground = Color.WHITE;
		background = new Color(64, 64, 64, 192);
	}
	
	@Override
	protected void renderComponent(Label label)
	{
		translateComponent(label, false);
		label.getArea();
		int x = 0, y = 0;
		switch(label.getHorizontalAlignment())
		{
			case CENTER:
				x += label.getWidth() / 2
				- theme.getFontRenderer().getStringWidth(label.getText())
				/ 2;
				break;
			case RIGHT:
				x += label.getWidth()
				- theme.getFontRenderer().getStringWidth(label.getText())
				- 2;
				break;
			default:
				x += 2;
		}
		switch(label.getVerticalAlignment())
		{
			case TOP:
				y += 2;
				break;
			case BOTTOM:
				y += label.getHeight() - theme.getFontRenderer().FONT_HEIGHT - 2;
				break;
			default:
				y += label.getHeight() / 2 - theme.getFontRenderer().FONT_HEIGHT
				/ 2;
		}
		glEnable(GL_BLEND);
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_CULL_FACE);
		theme.getFontRenderer().drawString(label.getText(), x, y,
			RenderUtil.toRGBA(label.getForegroundColor()));
		glEnable(GL_CULL_FACE);
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_BLEND);
		translateComponent(label, true);
	}
	
	@Override
	protected Dimension getDefaultComponentSize(Label component)
	{
		return new Dimension(theme.getFontRenderer().getStringWidth(
			component.getText()) + 4,
			theme.getFontRenderer().FONT_HEIGHT + 4);
	}
}
