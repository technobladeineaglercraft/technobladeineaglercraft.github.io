`.UFO` images can be opened with [Ulead PhotoImpact X3](http://www.corel.com/).  
`.PNG` images can be opened with any image viewer/editor.
